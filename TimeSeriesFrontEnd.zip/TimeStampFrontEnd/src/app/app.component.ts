import {
  Component,
  OnInit,
  OnDestroy,
  AfterViewInit,
} from '@angular/core';
import { ToastrManager } from "ng6-toastr-notifications";
import { Chart } from 'angular-highcharts';
import * as Highcharts from 'highcharts';
import { Subscription } from 'rxjs';

import { TimeseriesService } from './service/timeseries.service';

import { Building, ObjectModel, DataField, FilterModel } from './model/series.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent implements OnInit, AfterViewInit, OnDestroy {
  baseUrl: string = null;
  isApiCallStart: boolean;
  isEndDateGet: boolean;
  private subscription: Subscription;

  buildings: Building[] = [];
  objectsList: ObjectModel[] = [];
  dataFields: DataField[] = [];

  chart: Chart;
  timeSeries: number[] = [];
  public selectedMoments: Date[] = [];

  filterModel: FilterModel = new FilterModel();

  constructor(
    private seriesService: TimeseriesService,
    private toastr: ToastrManager
  ) { }

  ngOnInit() {
    this.baseUrl = 'http://localhost:3000/api/';
    this.isApiCallStart = false;
    this.isEndDateGet = false;
    this.getAllBuilding();
    this.getAllObject();
    this.getAllDataField();
  }

  getAllBuilding() {
    this.subscription = this.seriesService.get(this.baseUrl + 'buildings').subscribe(
      (res: any) => {
        this.buildings = res.body.buildings;
      },
      (err: any) => {
        this.toastr.errorToastr(err);
      }
    );
  }

  getAllObject() {
    this.subscription = this.seriesService.get(this.baseUrl + 'objects').subscribe(
      (res: any) => {
        this.objectsList = res.body.objects;
      },
      (err: any) => {
        this.toastr.errorToastr(err);
      }
    );
  }

  getAllDataField() {
    this.subscription = this.seriesService.get(this.baseUrl + 'dataFields').subscribe(
      (res: any) => {
        this.dataFields = res.body.dataFields;
      },
      (err: any) => {
        this.toastr.errorToastr(err);
      }
    );
  }

  getAllFilteredReading() {
    this.isApiCallStart = true;
    if (this.filterModel.rangeDates[1] === null) {
      let fromDate = new Date(this.filterModel.rangeDates[0]);
      let toDate = fromDate.setMonth(fromDate.getMonth() + 1)
      this.filterModel.rangeDates[1] = new Date(toDate);
    }
    this.subscription = this.seriesService.post(this.baseUrl + 'readings/getAllReadings', this.filterModel).subscribe(
      (res: any) => {
        let readings = [];
        let readingList = res.body.readings;

        if (readingList && readingList.length > 0) {
          readingList.forEach(item => {
            readings.push([new Date(item.timeStamp).getTime(), item.value]);
          })
        }
        this.generateTimeSeriesChart(readings);
      },
      (err: any) => {
        this.isApiCallStart = false;
        console.error(err);
      },
      () => {
        this.isApiCallStart = false;
      }
    );
  }

  generateTimeSeriesChart(data: any) {
    const rgbaColor = Highcharts.color(Highcharts.getOptions().colors[2])
      .setOpacity(0)
      .get('rgba');

    const chart = new Chart({
      chart: {
        zoomType: 'x',
      },
      title: {
        text: 'Time series',
      },
      xAxis: {
        type: 'datetime',
      },
      yAxis: {
        title: {
          text: 'value',
        },
      },
      legend: {
        enabled: false,
      },
      plotOptions: {
        area: {
          fillColor: {
            linearGradient: {
              x1: 0,
              y1: 0,
              x2: 0,
              y2: 0,
            },
            stops: [
              [0, Highcharts.getOptions().colors[2]],
              [1, `${rgbaColor}`],
            ],
          },
          marker: {
            radius: 2,
          },
          lineWidth: 1,
          states: {
            hover: {
              lineWidth: 1,
            },
          },
          threshold: null,
        },
      },
      series: [
        {
          type: 'area',
          name: 'value',
          data: data,
        },
      ],
    });

    this.chart = chart;
    chart.ref$.subscribe((res: any) => { });
    this.isApiCallStart = false;
  }

  closeTimeErrorAlart() {
    this.isEndDateGet = false;
  }

  ngAfterViewInit(): void {

  }

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }
}
