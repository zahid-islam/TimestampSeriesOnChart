export class Building {
    _id: string;
    name: string;
}

export class ObjectModel {
    _id: string;
    name: string;
}

export class DataField {
    _id: string;
    name: string;
}

export class FilterModel {
    buildingId: string;
    objectId: string;
    dataFieldID: string;
    rangeDates: Date[];
}