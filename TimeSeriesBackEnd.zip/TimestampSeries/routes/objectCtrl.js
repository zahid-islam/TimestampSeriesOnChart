const { Object, validate } = require('../models/object');
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
    const objects = await Object.find().select({ _id: 1, name: 1 });
    res.status(200).json({
        success: true,
        objects: objects
    });
});

router.post('/', async (req, res) => {
    try {
        const { error } = validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);

        let object = new Object({ name: req.body.name });
        object = await object.save();

        res.send(object);
    } catch (err) {
        throw err
    }
});

module.exports = router;