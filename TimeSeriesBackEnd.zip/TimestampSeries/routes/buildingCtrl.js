const { Building, validate } = require('../models/building');
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
    const buildings = await Building.find().select({ _id: 1, name: 1 });
    res.status(200).json({
        success: true,
        buildings: buildings
    });
});

router.post('/', async (req, res) => {
    try {
        const { error } = validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);

        let building = new Building({ name: req.body.name });
        building = await building.save();

        res.send(building);
    } catch (err) {
        throw err
    }
});

module.exports = router;