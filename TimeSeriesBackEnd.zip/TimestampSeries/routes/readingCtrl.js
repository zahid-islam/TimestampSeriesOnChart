const { Reading, validate } = require('../models/reading');
const { Building } = require('../models/building');
const { Object } = require('../models/object');
const { DataField } = require('../models/dataField');

const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

router.post('/getAllReadings', async (req, res) => {
    const buildingId = req.body.buildingId;
    const objectId = req.body.objectId;
    const dataId = req.body.dataFieldID;
    const startDate = req.body.rangeDates[0];
    const endDate = req.body.rangeDates[1];

    const readings = await Reading.find({
        timeStamp: {
            $gte: startDate,
            $lte: endDate,
        },
        buildingId: {
            $eq: buildingId
        },
        objectId: {
            $eq: objectId
        },
        dataFieldID: {
            $eq: dataId
        }
    }
    ).select({ timeStamp: 1, value: 1 });

    res.status(201).json({
        success: true,
        readings: readings
    });
});

router.post('/', async (req, res) => {
    try {
        const { error } = validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);

        const building = await Building.findById({ _id: req.body.buildingId });
        if (!building) return res.status(400).send('Invalid building.');

        const object = await Object.findById({ _id: req.body.objectId });
        if (!object) return res.status(400).send('Invalid Object.');

        const dataField = await DataField.findById({ _id: req.body.dataFieldID });
        if (!dataField) return res.status(400).send('Invalid data field.');

        // let timeInMilis = 1556215230000;
        // for (let i = 0; i < 43194; i++) {
        //     timeInMilis = timeInMilis + 6000;
        //     let reading = new Reading({
        //         value: Math.floor(Math.random() * 100) + 1,
        //         timeStamp: new Date(timeInMilis),
        //         buildingId: req.body.buildingId,
        //         objectId: req.body.objectId,
        //         dataFieldID: req.body.dataFieldID
        //     });
        //     reading = await reading.save();
        // }

        let reading = new Reading({
            value: req.body.value,
            timeStamp: new Date(req.body.timeStamp),
            buildingId: req.body.buildingId,
            objectId: req.body.objectId,
            dataFieldID: req.body.dataFieldID
        });
        reading = await reading.save();

        res.send(reading);
    } catch (err) {
        throw err
    }
});


module.exports = router;