const { DataField, validate } = require('../models/dataField');
const mongoose = require('mongoose');
const express = require('express');
const router = express.Router();

router.get('/', async (req, res) => {
    const dataFields = await DataField.find().sort({ _id: 1, name: 1 });
    res.status(200).json({
        success: true,
        dataFields: dataFields
    });
});

router.post('/', async (req, res) => {
    try {
        const { error } = validate(req.body);
        if (error) return res.status(400).send(error.details[0].message);

        let dataField = new DataField({ name: req.body.name });
        dataField = await dataField.save();

        res.send(dataField);
    } catch (error) {
        throw err
    }

});

module.exports = router;