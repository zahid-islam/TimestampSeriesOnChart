const Joi = require('joi');
const mongoose = require('mongoose');

const objectSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 50,
        unique: true
    }
});

const Object = mongoose.model('Object', objectSchema);

function validateObject(object) {
    const schema = {
        name: Joi.string().min(1).max(50).required()
    }
    return Joi.validate(object, schema);
}

exports.Object = Object;
exports.validate = validateObject;