const Joi = require('joi');
const mongoose = require('mongoose');

const dataFieldSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 50,
        unique: true
    }
});

const DataField = mongoose.model('DataField', dataFieldSchema);

function validateDataField(dataField) {
    const schema = {
        name: Joi.string().min(1).max(50).required()
    }
    return Joi.validate(dataField, schema);
}

exports.DataField = DataField;
exports.validate = validateDataField;