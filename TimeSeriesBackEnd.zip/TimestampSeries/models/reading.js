const Joi = require('joi');
const mongoose = require('mongoose');

const readingSchema = new mongoose.Schema({
    value: {
        type: Number,
        required: true
    },
    timeStamp: {
        type: Date,
        required: true
    },
    buildingId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Building',
        required: true
    },
    objectId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Object',
        required: true
    },
    dataFieldID: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'DataField',
        required: true
    }
});

const Reading = mongoose.model('Reading', readingSchema);

function validateReading(reading) {
    const schema = {
        value: Joi.number().required(),
        timeStamp: Joi.number().required(),
        buildingId: Joi.string().required(),
        objectId: Joi.string().required(),
        dataFieldID: Joi.string().required()
    }
    return Joi.validate(reading, schema);
}

exports.Reading = Reading;
exports.validate = validateReading;