const Joi = require('joi');
const mongoose = require('mongoose');

const buildingSchema = new mongoose.Schema({
    name: {
        type: String,
        required: true,
        minlength: 1,
        maxlength: 50,
        unique: true
    },
    location: {
        type: String,
        minlength: 1,
        maxlength: 50
    }
});

const Building = mongoose.model('Building', buildingSchema);

function validateBuilding(building) {
    const schema = {
        name: Joi.string().min(1).max(50).required(),
        location: Joi.string().min(1).max(50).required()
    }
    return Joi.validate(building, schema);
}

exports.Building = Building;
exports.validate = validateBuilding;