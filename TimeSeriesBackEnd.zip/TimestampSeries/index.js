const config = require('config');
const Joi = require('joi');
Joi.objectId = require('joi-objectid')(Joi);
const mongoose = require('mongoose');
const cors = require('cors');

const buildingRoute = require('./routes/buildingCtrl');
const objectRoute = require('./routes/objectCtrl');
const dataFieldRoute = require('./routes/dataFieldCtrl');
const readingRoute = require('./routes/readingCtrl');

const express = require('express');
const app = express();
app.use(cors({ origin: 'http://localhost:4200' }));
// if (!config.get('jwtPrivateKey')) {
//   console.error('FATAL ERROR: jwtPrivateKey is not defined.');
//   process.exit(1);
// }

mongoose.connect('mongodb://localhost/time_series', { useCreateIndex: true, useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB...'))
  .catch(err => console.error('Could not connect to MongoDB...'));

app.use(express.json());
app.use('/api/buildings', buildingRoute);
app.use('/api/objects', objectRoute);
app.use('/api/dataFields', dataFieldRoute);
app.use('/api/readings', readingRoute);

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Listening on port ${port}...`));